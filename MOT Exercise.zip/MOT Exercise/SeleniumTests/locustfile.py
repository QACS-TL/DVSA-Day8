from locust import HttpUser, task, between
from SeleniumUnitTestsForMOTSearchPage import TestMOTPage

import unittest
class HelloWorldUser(HttpUser):
    wait_time = between(1, 2)

    @task
    def hello_world(self):
        self.client.get("/")
        
    @task
    def DVSA_Search(self):
        self.client.get("/MOTPage.html")
        testpage = TestMOTPage()
        testpage.setUpClass()
        testpage.test_search_for_existing_Registration()