from SeleniumUnitTestsForMOTSearchPage import TestMOTPage
import sys

def main():
    testPage = TestMOTPage()
    testPage.setUpClass()
    testPage.test_search_for_existing_Registration()
    testPage.tearDownClass()
    

if __name__ == "__main__":
    import cProfile
    # cProfile.run("main()") # Display stats to console.
    cProfile.run("main()", "stats.prof") # Write stats to file.
    sys.exit(0)