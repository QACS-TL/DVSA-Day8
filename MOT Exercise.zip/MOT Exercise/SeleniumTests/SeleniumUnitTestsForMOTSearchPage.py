from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
import time

import unittest

class TestMOTPage(unittest.TestCase):
    
    @classmethod
    def setUpClass(cls):
        cls.driver = webdriver.Edge()
        cls.driver.get('http://127.0.0.1:5501/MOTPage.html')
    
    @classmethod
    def tearDownClass(cls):        
        cls.driver.quit()
    
    def test_search_for_existing_Registration(self):
        # self.driver.get('http://127.0.0.1:5501/MOTPage.html')
        element = self.driver.find_element(By.ID, 'searchText')
        element.clear()
        element.send_keys('XYZ987')
        button = self.driver.find_element(By.ID, 'find_car_by_reg')
        button.click()

        time.sleep(2.0)
        
        element = self.driver.find_element(By.ID, 'motTestNumber')

        self.assertEqual("789012345678", element.text)
        
        # driver.quit()
        
    def test_search_for_existing_MOT_number(self):
        # self.driver.get('http://127.0.0.1:5501/MOTPage.html')
        element = self.driver.find_element(By.ID, 'searchText')
        element.clear()
        element.send_keys('789012345678')
        button = self.driver.find_element(By.ID, 'find_car_by_mot_number')
        button.click()

        time.sleep(2.0)
        
        element = self.driver.find_element(By.ID, 'registrationNumber')

        self.assertEqual("XYZ987", element.text)
        
        # driver.quit()
    
            
    def test_search_for_NON_existing_MOT_number(self):
        # driver = webdriver.Edge()
        # self.driver.get('http://127.0.0.1:5501/MOTPage.html')   
        # driver.get('http://127.0.0.1:5501/MOTPage.html')

        element = self.driver.find_element(By.ID, 'searchText')
        element.clear()
        element.send_keys('111111111111')
        button = self.driver.find_element(By.ID, 'find_car_by_mot_number')
        button.click()

        time.sleep(0.5)
        
        element = self.driver.find_element(By.ID, 'results')

        self.assertEqual("Number NOT found", element.text)
        
        # driver.quit()
        
                
    def test_search_for_NON_existing_registration(self):
        # driver = webdriver.Edge()
        # self.driver.get('http://127.0.0.1:5501/MOTPage.html')
        # driver.get('http://127.0.0.1:5501/MOTPage.html')

        element = self.driver.find_element(By.ID, 'searchText')
        element.clear()
        element.send_keys('AAA987')
        button = self.driver.find_element(By.ID, 'find_car_by_reg')
        button.click()

        time.sleep(0.5)
        
        element = self.driver.find_element(By.ID, 'results')

        self.assertEqual("Number NOT found", element.text)
        
        # driver.quit()
        