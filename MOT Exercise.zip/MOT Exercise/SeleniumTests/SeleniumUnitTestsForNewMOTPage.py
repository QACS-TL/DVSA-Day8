from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import Select
import time
import sqlite3
import unittest

class TestNewMOTPage(unittest.TestCase):
    
    
    @classmethod
    def setUpClass(cls):
        cls.driver = webdriver.Edge()
        cls.driver.get('http://127.0.0.1:5501/NewMOTTestPage.html')
        # ensure a particular row is not in the database and another one is
        sqliteConnection = sqlite3.connect(r"E:\QAL\DVSA\Day 8 Testing\MOT Exercise\DVSA_MOT_Python_API\vehicles.db")
        cursor = sqliteConnection.cursor()
        query = "DELETE FROM vehicle WHERE registrationNumber='BCA 321'"
        cursor.execute(query)
        sqliteConnection.commit()
        query = "INSERT INTO vehicle (registrationNumber, motTestNumber, make, model, year, fueltype, mileage, testDate, expiryDate, testResult, advisoryItems , defects) VALUES ('CBA 123', '454545454545', 'Honda', 'Civic', 2018, 'Petrol', 26534, '2024-02-26 00:00:00.0000', '2025-02-26 00:00:00.0000', 'PASS', '', '')"
        cursor.execute(query)
        sqliteConnection.commit()
        sqliteConnection.close()
     

    @classmethod
    def tearDownClass(cls):        
        cls.driver.quit()
    
    def test_add_new_vehicle_to_database(self):
        # self.driver.get('http://127.0.0.1:5501/NewMOTTestPage.html')
        regnum = 'BCA 321'
        element = self.driver.find_element(By.ID, 'registrationNumber')
        element.clear()
        element.send_keys(regnum)

        element = self.driver.find_element(By.ID, 'motTestNumber')
        element.clear()
        element.send_keys('222222222222')        

        element = self.driver.find_element(By.ID, 'make')
        element.clear()
        element.send_keys('Ford')            

        element = self.driver.find_element(By.ID, 'model')
        element.clear()
        element.send_keys('Fiesta')   
        
        element = self.driver.find_element(By.ID, 'year')
        element.clear()
        element.send_keys('2020')   
        
        select = Select(self.driver.find_element(By.ID, 'fuelType'))
        select.select_by_index(1)   
        
        element = self.driver.find_element(By.ID, 'mileage')
        element.clear()
        element.send_keys(23001) 
                       
        select = Select(self.driver.find_element(By.ID, 'testResult'))
        select.select_by_index(1)  
                       
        element = self.driver.find_element(By.ID, 'advisoryItems')
        element.clear()
        element.send_keys('Front brake pads, advice: Appear to be made of cheese; Tyre tread depth, advice: Approaching legal limit')  
                               
        element = self.driver.find_element(By.ID, 'defects')
        element.clear()
        element.send_keys('Fuel leak, advice: No naked flames; Music System, advice: Retune to a better music station')  
                                 
        button = self.driver.find_element(By.ID, 'okButton')
        button.click()

        time.sleep(2.0)
        
        element = self.driver.find_element(By.ID, 'message')
        
        self.assertEqual(f"Added new vehicle with a registration of {regnum} to the database", element.text)
      
         
    def test_attempt_to_add_existing_vehicle_to_database(self):
        # self.driver.get('http://127.0.0.1:5501/NewMOTTestPage.html')
        regnum = 'CBA 123'
        element = self.driver.find_element(By.ID, 'registrationNumber')
        element.clear()
        element.send_keys(regnum)

        element = self.driver.find_element(By.ID, 'motTestNumber')
        element.clear()
        element.send_keys('222222222222')        

        element = self.driver.find_element(By.ID, 'make')
        element.clear()
        element.send_keys('Ford')            

        element = self.driver.find_element(By.ID, 'model')
        element.clear()
        element.send_keys('Fiesta')   
        
        element = self.driver.find_element(By.ID, 'year')
        element.clear()
        element.send_keys('2020')   
        
        select = Select(self.driver.find_element(By.ID, 'fuelType'))
        select.select_by_index(2)   
         
        element = self.driver.find_element(By.ID, 'mileage')
        element.clear()
        element.send_keys(23001) 
                       
        select = Select(self.driver.find_element(By.ID, 'testResult'))
        select.select_by_index(0)  
                       
        element = self.driver.find_element(By.ID, 'advisoryItems')
        element.clear()
        element.send_keys('Front brake pads, advice: Appear to be made of cheese; Tyre tread depth, advice: Approaching legal limit')  
                               
        element = self.driver.find_element(By.ID, 'defects')
        element.clear()
        element.send_keys('Fuel leak, advice: No naked flames; Music System, advice: Retune to a better music station')  
                                 
        button = self.driver.find_element(By.ID, 'okButton')
        button.click()

        time.sleep(2.0)
        
        element = self.driver.find_element(By.ID, 'message')        
        self.assertEqual(f"A vehicle with a registration of {regnum} is already in the vehicles table", element.text)
        

        
 
        