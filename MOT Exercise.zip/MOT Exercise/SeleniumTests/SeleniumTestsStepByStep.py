from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
import time

import unittest

class TestMOTPage(unittest.TestCase):
    
    def test_search_for_existing_Registration(self):
        self.driver.get('http://127.0.0.1:5501/MOTPage.html')
