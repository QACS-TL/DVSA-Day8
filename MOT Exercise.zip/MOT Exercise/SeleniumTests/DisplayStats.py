import sys
from pstats import Stats

my_stat = Stats('stats.prof', stream=sys.stdout)
my_stat.print_stats()
