from flask import Flask, Response, request, jsonify
from flask_sqlalchemy import SQLAlchemy
from dataclasses import dataclass
from datetime import datetime, date
from flask_cors import CORS

app = Flask(__name__)
CORS(app, origins=["http://127.0.0.1:5501", "http://127.0.0.1:5501"])

connection_url = 'sqlite:///vehicles.db'
app.config['SQLALCHEMY_DATABASE_URI'] = connection_url

db = SQLAlchemy(app)


@dataclass
class Vehicle(db.Model):
    id:int = db.Column(db.Integer, primary_key=True, autoincrement=True)
    registrationNumber:str = db.Column(db.String(8))
    motTestNumber:str = db.Column(db.String(12))
    make:str = db.Column(db.String(20))
    model:str = db.Column(db.String(20))
    year:str = db.Column(db.Integer)
    fuelType:str = db.Column(db.String(10))
    mileage:str = db.Column(db.Integer)
    testDate:str = db.Column(db.DateTime)
    expiryDate:str = db.Column(db.DateTime)
    testResult:str = db.Column(db.String(4))
    advisoryItems:str = db.Column(db.String(100))
    defects:str = db.Column(db.String(100))

db.create_all()

@app.route('/vehicle_registrations', methods=['GET'])
def vehicle_registrations():
    query = db.session.query(Vehicle)
    all_vehicles = query.all()
    vehicles_string = ""
    #return all_vehicles
    for vehicle in all_vehicles:
        vehicles_string += "<br>" + vehicle.registrationNumber
    response = jsonify(vehicles_string)
    # response.headers.add("Access-Control-Allow-Origin", "*")
    return response

@app.route('/get_vehicle_by_id/<int:id>', methods=['GET'])
def get_vehicle_by_id(id):
    query = db.session.query(Vehicle)
    vehicle = query.get(id)
    if vehicle is not None:
        vehicle_as_json = jsonify(vehicle)
        return vehicle_as_json
        # Alternate solution that uses Response method
        # vehicle_as_data = vehicle_as_json.data
        # return Response(vehicle_as_data, mimetype='application/json')
    else:
        return jsonify("No such vehicle")

@app.route('/vehicles', methods=['GET'])
def vehicles_as_json():
    query = db.session.query(Vehicle)
    all_vehicles = query.all()
    return jsonify(all_vehicles)


@app.route('/vehicles', methods=['PUT'])
def update_vehicle_reg():
    vehicle = request.get_json()
    id = vehicle['id']
    registrationNo = vehicle['registrationNumber']
    motTestNumber = vehicle['motTestNumber']
    make = vehicle['make']
    model = vehicle['model']
    year = vehicle['year']
    fuelType = vehicle['fuelType']
    mileage = vehicle['mileage']
    testDate = vehicle['testDate']
    expiryDate = vehicle['expiryDate']
    testResult = vehicle['testResult']
    advisoryItems = vehicle['advisoryItems']
    defects = vehicle['defects']

    # registrationNumber = request.form.get('registrationNumber')
    try:
        query = db.session.query(Vehicle)
        actual_vehicle = query.get(id)
        if actual_vehicle is not None:
            actual_vehicle.registrationNumber = registrationNo
            actual_vehicle.motTestNumber = motTestNumber
            actual_vehicle.make = make
            actual_vehicle.model = model
            actual_vehicle.year = year
            actual_vehicle.fuelType = fuelType
            actual_vehicle.mileage = mileage
            actual_vehicle.testDate = datetime.strptime(testDate, "%Y-%m-%d").date()
            actual_vehicle.expiryDate = datetime.strptime(expiryDate, "%Y-%m-%d").date()
            actual_vehicle.testResult = testResult
            actual_vehicle.advisoryItems = advisoryItems
            actual_vehicle.defects = defects
            db.session.commit()
            return jsonify(f"Vehicle with id of {id}'s details have been successfully updated")
        else:
            return jsonify(f"Vehicle {id} not in database")
    except Exception as error:
        return error.__str__

@app.route('/vehicles', methods=['POST'])
def add_vehicle():
    vehicle = request.get_json()
    registrationNo = vehicle['registrationNumber']
    motTestNumber = vehicle['motTestNumber']
    make = vehicle['make']
    model = vehicle['model']
    year = vehicle['year']
    fuelType = vehicle['fuelType']
    mileage = vehicle['mileage']
    testDate = vehicle['testDate']
    expiryDate = vehicle['expiryDate']
    testResult = vehicle['testResult']
    advisoryItems = vehicle['advisoryItems']
    defects = vehicle['defects']

    try:
        vehicle = db.session.query(Vehicle).filter(Vehicle.registrationNumber == registrationNo).first()
        if vehicle is None:
            new_vehicle = Vehicle(
                                registrationNumber=registrationNo,
                                motTestNumber=motTestNumber,
                                make=make,
                                model=model,
                                year=year,
                                fuelType=fuelType,
                                mileage=mileage,
                                testDate= datetime.strptime(testDate, "%a %b %d %Y").date(),
                                expiryDate=datetime.strptime(expiryDate, "%a %b %d %Y").date(),
                                testResult=testResult,
                                advisoryItems=advisoryItems,
                                defects=defects)
            db.session.add(new_vehicle)
            db.session.flush()
            db.session.refresh(new_vehicle)  # used to determine value of id column generated by the database
            db.session.commit()
            return jsonify(f"Added new vehicle with a registration of {registrationNo} to the database")
        else:
            return jsonify(f"A vehicle with a registration of {registrationNo} is already in the vehicles table")
    except Exception as error:
        return error.__str__

@app.route('/vehicles/<id>', methods=['DELETE'])
def delete_vehicle(id):
    # id = request.json['id']
    query = db.session.query(Vehicle)
    vehicle = query.get(id)
    if vehicle is not None:
        db.session.delete(vehicle)
        db.session.commit()
        return jsonify(f"The vehicle with an id of {vehicle.id} has been successfully removed from the database")
    else:
        return jsonify(f"Deletion Failed! A vehicle with an id of {id} does not exist in the vehicles table")

if __name__ == '__main__':
    app.run()
