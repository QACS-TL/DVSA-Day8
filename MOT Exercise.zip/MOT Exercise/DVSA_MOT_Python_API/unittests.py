import pytest
from app import app

import unittest

class TestDVSAAPI(unittest.TestCase):
   
    def setUp(self):
        self.client = app.test_client()

        # yield client
        
    def test_search_for_existing_Registration(self):
       landing = self.client.get("/vehicles")
       json_vehicles = landing.data.decode()
       vehicles = eval(json_vehicles)
       vehicle = vehicles[0]['registrationNumber']
       self.assertEquals("XYZ987",vehicle )
        